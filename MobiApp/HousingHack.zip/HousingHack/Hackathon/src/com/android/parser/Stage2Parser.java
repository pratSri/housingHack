package com.android.parser;

import java.io.InputStream;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.android.model.Secondary;


public class Stage2Parser {

	private static Stage2Parser mInstance;
	static InputStream mInputStream = null;
	static JSONObject mJsonObject = null;
	static String mJsonString = "";
	

	/**
	 * Make Constructor private to implement singleton.
	 */
	private Stage2Parser() {

	}

	/**
	 * Return a single instance of {@link Stage2Parser}
	 * 
	 * @return {@link Stage2Parser}
	 */
	public static Stage2Parser getInstance() {
		if (mInstance == null) {
			mInstance = new Stage2Parser();
		}

		return mInstance;
	}

	public ArrayList<Secondary> parseData(String response) {
		ArrayList<Secondary> DataList = new ArrayList<Secondary>();
		JSONArray jsonObj = null;
		Secondary item = null;
		try {
			jsonObj = new JSONArray(response);

			for (int i = 0; i < jsonObj.length(); i++) {
				JSONObject itemDetails = jsonObj.getJSONObject(i);

				if (itemDetails != null) {
					item = new Secondary();
					item.setLatitude(itemDetails
							.getDouble("Latitude"));
					item.setLongitude(itemDetails
							.getDouble("Longitude"));
					item.setViews(itemDetails
							.getString("No_of_views"));
					item.setName(itemDetails
							.getString("Owner_name"));
					item.setNumber(itemDetails
							.getString("Owner_phn"));
					item.setArea(itemDetails
							.getString("Area_sqft"));
					item.setIntrest(itemDetails
							.getString("Intrest"));
					item.setSchools(itemDetails
							.getString("Schools"));
					item.setPubs(itemDetails
							.getString("Pubs"));
					item.setBanks(itemDetails
							.getString("Banks"));
					item.setHospitals(itemDetails
							.getString("Hospitals"));

				}
				DataList.add(item);

			}
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return DataList;
	}

}