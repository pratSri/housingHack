package com.android.hackathon;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapter extends BaseAdapter{
    private Context acontext;
    private ArrayList<String> array_area;
    private ArrayList<String> array_price;
    private ArrayList<String> array_about;
    private ArrayList<String> array_postdate;
    public CustomAdapter(Context context, ArrayList<String> area, ArrayList<String> price, ArrayList<String> about, ArrayList<String> postdate){
        this.acontext=context;
        this.array_area=area;
        this.array_price=price;
        this.array_about=about;
        this.array_postdate=postdate;
    }
    @Override
    public int getCount() {
        return array_area.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        Holder holder = new Holder();
        LayoutInflater layoutInflater = (LayoutInflater)acontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = layoutInflater.inflate(R.layout.listitems, viewGroup, false);
        //ImageView imageView = (ImageView) rowView.findViewById(R.id.image1);
        holder.txt_area = (TextView) view.findViewById(R.id.area);
        holder.txt_price = (TextView) view.findViewById(R.id.price);
        holder.txt_about = (TextView) view.findViewById(R.id.about);
        holder.txtx_postdate = (TextView) view.findViewById(R.id.postdate);

        holder.txt_area.setText(array_area.get(i));
        holder.txt_price.setText(array_price.get(i));
        holder.txt_about.setText(array_about.get(i));
        holder.txtx_postdate.setText(array_postdate.get(i));


        return view;
    }
    public class Holder {

        TextView txt_area;
        TextView txt_price;
        TextView txt_about;
        TextView txtx_postdate;
    }


}
