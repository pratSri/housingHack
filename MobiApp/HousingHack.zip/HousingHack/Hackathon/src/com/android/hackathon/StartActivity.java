package com.android.hackathon;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class StartActivity extends Activity implements OnClickListener {
	
	Button comBtn, resBtn, agriBtn, indsBtn;
	TextView label1, label2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getActionBar().setTitle("Home");
		setTitleColor(getResources().getColor(android.R.color.white));
		getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FFC107")));
		setContentView(R.layout.activity_start1);
	
		label1 = (TextView) findViewById(R.id.label1);
		label2 = (TextView) findViewById(R.id.label2);
		label1.setTypeface(Typeface.createFromAsset(getAssets(), "JosefinSlab.ttf"));
		label2.setTypeface(Typeface.createFromAsset(getAssets(), "JosefinSlab.ttf"));
		
		comBtn = (Button) findViewById(R.id.comBtn);
		resBtn = (Button) findViewById(R.id.resBtn);
		agriBtn = (Button) findViewById(R.id.agriBtn);
		indsBtn = (Button) findViewById(R.id.indstBtn);
		
		comBtn.setOnClickListener(this);
		resBtn.setOnClickListener(this);
		agriBtn.setOnClickListener(this);
		indsBtn.setOnClickListener(this);
	}
	@Override
	public void onClick(View v) {
		switch(v.getId()){
		case R.id.comBtn:
			 Intent comIntent = new Intent(this,MainActivity.class);
			 comIntent.putExtra("Type", "Commercial");
			 startActivity(comIntent);
			 break;
		case R.id.resBtn:
			 Intent resIntent = new Intent(this,MainActivity.class);
			 resIntent.putExtra("Type", "Residential");
			 startActivity(resIntent);
			break;
		case R.id.agriBtn:
			 Intent agrIntent = new Intent(this,MainActivity.class);
			 agrIntent.putExtra("Type", "Agricultural");
			 startActivity(agrIntent);
			break;
		case R.id.indstBtn:
			 Intent indIntent = new Intent(this,MainActivity.class);
			 indIntent.putExtra("Type", "Industrial");
			 startActivity(indIntent);
			break;
		default:
			break;
			
		}
		
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.start, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_search) {
			Intent i = new Intent(this, SearchActivity.class);
			startActivity(i);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	
}
