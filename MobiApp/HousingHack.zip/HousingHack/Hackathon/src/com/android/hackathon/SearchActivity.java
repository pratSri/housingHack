package com.android.hackathon;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SearchActivity extends Activity {
	TextView label1,label2;
	Button search;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setTitle("Search");
		setTitleColor(getResources().getColor(android.R.color.white));
		getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FFC107")));
		setContentView(R.layout.activity_search);
		label1 = (TextView) findViewById(R.id.label3);
		label2 = (TextView) findViewById(R.id.label4);
		label1.setTypeface(Typeface.createFromAsset(getAssets(), "JosefinSlab.ttf"));
		label2.setTypeface(Typeface.createFromAsset(getAssets(), "JosefinSlab.ttf"));
		
		search = (Button) findViewById(R.id.searchBtn);
		search.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Toast.makeText(getApplicationContext(), "Later Baby", Toast.LENGTH_SHORT).show();
				
			}
		});
	}

}
