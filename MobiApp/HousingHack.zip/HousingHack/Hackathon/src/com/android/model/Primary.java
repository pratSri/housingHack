package com.android.model;

public class Primary {
	
		private String Property_id;
		private String About;
		private String Price;
		private String Locality;
		private String created;
		public Primary() {
			About = "";
			Property_id = "";
			Price = "";
			Locality = "";
			created = "";
			
		}
		

		public String getAbout() {
			return About;
		}

		public void setAbout(String About) {
			this.About = About;
		}

		public String getId() {
			return Property_id;
		}

		public void setId(String Property_id) {
			this.Property_id = Property_id;
		}
		
		public String getPrice() {
			return Price;

		}

		public void setPrice(String Price) {
			this.Price = Price;
		}

		
		public String getLocality() {
			return Locality;
		}

		public void setLocality(String locality) {
			this.Locality = locality;
		}
		
		public String getCreated() {
			return created;
		}
		
		public void setCreated(String Created) {
			this.created = Created;
		}
		


}
