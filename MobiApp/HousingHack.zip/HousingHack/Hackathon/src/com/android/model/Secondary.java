package com.android.model;

public class Secondary {
	
		private Double latitude;
		private Double longitude;
		private String views;
		private String name;
		private String number;
		private String area;
		private String intrest;
		private String schools;
		private String pubs;
		private String banks;
		private String hospitals;

		public Secondary() {
			latitude = null;
			longitude = null;
			views = "";
			name = "";
			number = "";
			area = "";
			intrest = "";
			schools = "";
			pubs = "";
			banks = "";
			hospitals = "";
					
		}

		public void setLatitude(Double Latitude) {
			this.latitude = Latitude;
		}

		public Double getLatitude() {
			return latitude;
		}

		public void setLongitude(Double Longitude) {
			this.longitude = Longitude;
		}

		public Double getLongitude() {
			return longitude;

		}

		public void setViews(String Views) {
			this.views = Views;
		}

		public String getViews() {
			return views;

		}

		public void setName(String Name) {
			this.name = Name;
		}

		public String getName() {
			return name;

		}

		public void setNumber(String Number) {
			this.number = Number;
		}

		public String getNumber() {
			return number;

		}

		public void setArea(String Area) {
			this.area = Area;
		}

		public String getArea() {
			return area;

		}
		
		public void setSchools(String Schools) {
			this.schools = Schools;
		}

		public String getSchools() {
			return schools;

		}
		public void setPubs(String Pubs) {
			this.pubs = Pubs;
		}

		public String getPubs() {
			return intrest;

		}		
		public void setBanks(String Banks) {
			this.banks = Banks;
		}

		public String getBanks() {
			return intrest;

		}
		public void setIntrest(String intrest) {
			this.intrest = intrest;
		}

		public String getIntrest() {
			return intrest;

		}
		public void setHospitals(String Hospitals) {
			this.hospitals = Hospitals;
		}

		public String getHospitals() {
			return hospitals;

		}
}
