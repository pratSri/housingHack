package com.android.hackathon;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import com.android.model.Primary;
import com.android.parser.Stage1Parser;

import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ParseException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.view.View.OnClickListener;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;


public  class ItemFragment extends Fragment {
	private ArrayList<String> locality = new ArrayList<String>();
    private ArrayList<String> price = new ArrayList<String>();
    private ArrayList<String> about = new ArrayList<String>();
    private ArrayList<String> postdate = new ArrayList<String>();
	private  ListView listView;
    CustomAdapter customAdapter;
	ProgressDialog dialog;
	private String type;
	View rootView;
	Primary item;
	ArrayList<Primary> DataList;
	
    
    public ItemFragment() {
        // Empty constructor required for fragment subclasses
    }
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
    	setRetainInstance(true);
    	type = getArguments().getString("Type");
    	DataList = new ArrayList<Primary>();
    	new DATAsyncTask(type).execute();
    	rootView = inflater.inflate(R.layout.listview, container, false);
        return rootView;
   }
   @Override
   public void onActivityCreated(Bundle savedInstanceState) {
	super.onActivityCreated(savedInstanceState);
	
   }
   
   class DATAsyncTask extends AsyncTask<Void, Void, String> {
		
		
		String type;
		String Flag="NO";
		int flag=1;
		
		public DATAsyncTask(String type){
 	      this.type = type;
 	  	}
		
		@Override
	protected void onPreExecute() {
		super.onPreExecute();
		dialog = new ProgressDialog(getActivity());
		dialog.setMessage("Fetching Data from server...");
		//dialog.setTitle("Connecting server");
		dialog.show();
		dialog.setCancelable(false);
		
	}
		
		@Override
		protected String doInBackground(Void... urls) {
			
			/*	
			try {	 	
				ArrayList<NameValuePair> nV = new ArrayList<NameValuePair>();
					nV.add(new BasicNameValuePair("Type", "1"));
					
				HttpPost httppost = new HttpPost("192.168.43.38:58778");
				HttpClient httpclient = new DefaultHttpClient();
				httppost.setEntity(new UrlEncodedFormEntity(nV));
				HttpResponse response = httpclient.execute(httppost);
	            int status = response.getStatusLine().getStatusCode();
				if (status == 200) {
					HttpEntity entity = response.getEntity();
					String data = EntityUtils.toString(entity);				
					JSONObject jsono = new JSONObject(data);				
					if(jsono.has("error"))
						flag=0;
					else
						flag=1;
					return data;
				}
				
				//------------------>>
				
			} catch (ParseException e1) {
				e1.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (JSONException e) {
				e.printStackTrace();
			}*/
			String data = null;
			try {

		        InputStream is = getActivity().getAssets().open("data.json");

		        int size = is.available();

		        byte[] buffer = new byte[size];

		        is.read(buffer);

		        is.close();

		        data = new String(buffer, "UTF-8");


		    } catch (IOException ex) {
		        ex.printStackTrace();
		        return null;
		    }
			return data;
		}
		
		protected void onPostExecute(String result) {
			Log.d("response", result);
			
			if(flag==0)
				Toast.makeText(getActivity(), "Error in fetching data from server", Toast.LENGTH_LONG).show();
			if(result.equalsIgnoreCase(Flag)){
				Toast.makeText(getActivity(), "Network issues!!!  try again", Toast.LENGTH_LONG).show();
			}else{
				DataList = Stage1Parser.getInstance().parseData(result);
				for(int i=0;i<DataList.size();i++){
					item = DataList.get(i);
					about.add(item.getAbout());
					price.add(item.getPrice()+"/-");
					locality.add(item.getLocality());
					postdate.add(item.getCreated());
				}
				listView = (ListView) getActivity().findViewById(R.id.list1);
		    	customAdapter = new CustomAdapter(getActivity(), locality, price, about, postdate);	
				listView.setOnItemClickListener(new OnItemClickListener() {
				@Override
					public void onItemClick(AdapterView<?> parent, View view, int position,
							long id) {
						item = null;
						item = DataList.get(position);
						Intent i = new Intent(getActivity(), DetailActivity.class);
						i.putExtra("Locality", item.getLocality());
						i.putExtra("Price",item.getPrice());
						i.putExtra("About",item.getAbout());
						i.putExtra("Created",item.getCreated());
						i.putExtra("ID",item.getId());
						startActivity(i);	
					}
				});
				listView.setAdapter(customAdapter);
				dialog.cancel();
			}
		}
	}
/*
@Override
public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
	item = null;
	item = DataList.get(position);
	System.out.println(item.toString());
	Intent i = new Intent(getActivity(), DetailActivity.class);
	i.putExtra("Locality", item.getLocality());
	i.putExtra("Price",item.getPrice());
	i.putExtra("About",item.getAbout());
	i.putExtra("Created",item.getCreated());
	i.putExtra("ID",item.getId());
	startActivity(i);
	
}*/


}
  