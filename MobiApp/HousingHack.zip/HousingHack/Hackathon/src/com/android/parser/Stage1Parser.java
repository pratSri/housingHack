package com.android.parser;

import java.io.InputStream;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;

import com.android.model.Primary;
import com.android.parser.Stage1Parser;

public class Stage1Parser {
	
	private static Stage1Parser mInstance;
	static InputStream mInputStream = null;
	static JSONObject mJsonObject = null;
    String jsonName;
	String[] value,attribute;
   

	/**
	 * Make Constructor private to implement singleton.
	 */
	private Stage1Parser() {

	}

	/**
	 * Return a single instance of {@link JSONParser}
	 * 
	 * @return {@link JSONParser}
	 */
	public static Stage1Parser getInstance() {
		if (mInstance == null) {
			mInstance = new Stage1Parser();
		}

		return mInstance;
	}

	public ArrayList<Primary> parseData(String response) {
		ArrayList<Primary> DataList = new ArrayList<Primary>();
		Primary item = null;
		try {
			JSONObject jsono = new JSONObject(response);
			JSONArray jsonObj = jsono.getJSONArray("member_info");

			for (int i = 0; i < jsonObj.length(); i++) {
				JSONObject itemDetails = jsonObj.getJSONObject(i);

				if (itemDetails != null) {
					item = new Primary();
					item.setId(itemDetails
							.getString("Property_ID"));
					item.setAbout(itemDetails
							.getString("About"));
					item.setPrice(itemDetails
							.getString("Price"));
					item.setLocality(itemDetails
							.getString("Locality"));
					item.setCreated(itemDetails
							.getString("Created"));
				}
				DataList.add(item);

			}
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return DataList;
		}

}
