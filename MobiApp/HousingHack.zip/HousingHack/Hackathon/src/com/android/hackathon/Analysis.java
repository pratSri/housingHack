package com.android.hackathon;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class Analysis extends Activity {
    private TextView schools;
    private TextView pubs;
    private TextView banks;
    private TextView hospitals;
    static String s_schools,s_pubs,s_banks,s_hospitals;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Location Analysis");
        setTitleColor(getResources().getColor(android.R.color.white));
        getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FFC107")));
        setContentView(R.layout.loc_analysis);
        getActionBar().setDisplayHomeAsUpEnabled(true);
        schools = (TextView)findViewById(R.id.schools);
        pubs = (TextView)findViewById(R.id.pubs);
        banks = (TextView)findViewById(R.id.banks);
        hospitals = (TextView)findViewById(R.id.hospitals);
        s_schools = getIntent().getExtras().getString("Schools");
        s_pubs = getIntent().getExtras().getString("Pubs");
        s_banks = getIntent().getExtras().getString("Banks");
        s_hospitals = getIntent().getExtras().getString("Hospitals");
        schools.setText(s_schools);
        pubs.setText(s_pubs);
        banks.setText(s_banks);
        hospitals.setText(s_hospitals);
    }
    
    @Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.start, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_search) {
			Intent i = new Intent(this, SearchActivity.class);
			startActivity(i);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
