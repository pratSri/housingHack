package com.android.hackathon;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import com.android.model.Secondary;
import com.android.parser.Stage2Parser;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ParseException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class DetailActivity extends Activity {
	
	String About, Locality, Price, Created,Property_id,Schools, Pubs, Banks, Hospitals;
	TextView locality, price, created, viewCount, intrestCount, Name, Phn, area, about;
	Button anlBtn;
	Secondary item;
	ArrayList<Secondary> DataList;
	private GoogleMap mGoogleMap;
	private LatLng mItemLocation;
	ProgressDialog dialog;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setTitle("Details");
		setTitleColor(getResources().getColor(android.R.color.white));
		getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FFC107")));
		setContentView(R.layout.detail_layout);
		Intent i = getIntent();
		/*Property_id = i.getExtras().getString("ID");
		About = i.getExtras().getString("About");
		Locality = i.getExtras().getString("Locality");
		Price = i.getExtras().getString("Price");
		Created = i.getExtras().getString("Created");
		locality = (TextView) findViewById(R.id.loc);
		locality.setText(Locality);
		price = (TextView) findViewById(R.id.price);
		price.setText(Price);
		created = (TextView) findViewById(R.id.posted);
		created.setText(Created);
		viewCount = (TextView) findViewById(R.id.NoOfViews);
		intrestCount = (TextView) findViewById(R.id.NoOfIntrest);
		Name = (TextView) findViewById(R.id.owner_name);
		Phn = (TextView) findViewById(R.id.owner_no);
		area = (TextView) findViewById(R.id.area);
		about = (TextView) findViewById(R.id.about);
		anlBtn = (Button) findViewById(R.id.analysisBtn);
		anlBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent i = new Intent(getApplicationContext(),Analysis.class);
				i.putExtra("Schools", Schools);
				i.putExtra("Pubs", Pubs);
				i.putExtra("Banks", Banks);
				i.putExtra("Hospitals", Hospitals);
				startActivity(i);
				
			}
		});
		
	*/
		
	}
	
	  class DATAsyncTask extends AsyncTask<Void, Void, String> {
			
			
			String type;
			String Flag="NO";
			int flag;
			
			public DATAsyncTask(String type){
	 	      this.type = type;
	 	  	}
			
			@Override
		protected void onPreExecute() {
			super.onPreExecute();
			dialog = new ProgressDialog(getApplicationContext());
			dialog.setMessage("Fetching Data from server...");
			//dialog.setTitle("Connecting server");
			dialog.show();
			dialog.setCancelable(false);
			
		}
			
			@Override
			protected String doInBackground(Void... urls) {
				
					
				try {	 	
					HttpGet httppost = new HttpGet("127.0.0.2");
					HttpClient httpclient = new DefaultHttpClient();
					 				
					HttpResponse response = httpclient.execute(httppost);
		            int status = response.getStatusLine().getStatusCode();

					if (status == 200) {
						HttpEntity entity = response.getEntity();
						String data = EntityUtils.toString(entity);				
						JSONObject jsono = new JSONObject(data);				
						if(jsono.has("error"))
							flag=0;
						else
							flag=1;
						return data;
					}
					
					//------------------>>
					
				} catch (ParseException e1) {
					e1.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (JSONException e) {
					e.printStackTrace();
				}
				return Flag;
			}
			
			protected void onPostExecute(String result) {
				Log.d("response", result);
				
				if(flag==0)
					Toast.makeText(getApplicationContext(), "Error in fetching data from server", Toast.LENGTH_LONG).show();
				if(result.equalsIgnoreCase(Flag)){
					Toast.makeText(getApplicationContext(), "Network issues!!!  try again", Toast.LENGTH_LONG).show();
				}else{
					DataList = Stage2Parser.getInstance().parseData(result);
					for(int i=0;i<DataList.size();i++){	
						item = DataList.get(i);
						viewCount.setText(item.getViews());
						intrestCount.setText(item.getIntrest());
						Name.setText(item.getName());
						Phn.setText(item.getNumber());
						area.setText(item.getArea());
						about.setText(About);
						Schools = item.getSchools();
						Pubs = item.getPubs();
						Banks = item.getBanks();
						Hospitals= item.getHospitals();
					}
					mItemLocation = new LatLng(12.971599,
							77.594563);

					mGoogleMap = ((MapFragment) getFragmentManager()
							.findFragmentById(R.id.mapitem)).getMap();
					mGoogleMap.addMarker(new MarkerOptions()
							.position(mItemLocation).title("This"));
					mGoogleMap.setMyLocationEnabled(true);
					dialog.cancel();	
				}
			}
		}
}
